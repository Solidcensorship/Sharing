public class Score {
    private int score;
    private int numberOfTurns;

    Score () {
        score = 0;
        numberOfTurns = 0;
    }

    public int getScore() {
        return score;
    }

    public int getNumberOfTurns () {
        return numberOfTurns;
    }
}
