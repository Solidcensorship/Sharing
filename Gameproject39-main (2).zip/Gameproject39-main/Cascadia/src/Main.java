import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        int turn = 0;
        Scanner scan = new Scanner(System.in);
        Scanner scanNum = new Scanner(System.in);
        Board board = new Board();
        Score scoreboard = new Score();
        View view = new View();
        view.displayWelcome();
        board.setupBoard();
        board.setupPlayer();
        board.setOrder();
        board.assignStarterTile();

        while (turn < 20) {
            for (int i = 0; i < board.player.length; i++) {
                board.turn(i);
            }
            turn++;
            view.displayTurnNum(turn);
            view.displayScore();
        }
    }
}