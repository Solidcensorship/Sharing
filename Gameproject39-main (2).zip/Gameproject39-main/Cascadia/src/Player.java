public class Player {
    private String playerName;
    private int playerScore;

    public Player(String name, int score) {
        this.playerName = name;
        this.playerScore = playerScore;
    }

    public String getPlayerName() {
        return playerName;
    }

    public int getPlayerScore() {
        return playerScore;
    }

}
