public class View {

    public void displayWelcome(){
        System.out.println("Welcome to Cascadia!\n\n");
    }

    public void displayScore(){
        System.out.println("This is the score\n");
    }

    public void displayTurnNum(int turn){
        System.out.println("It is now turn" + turn + "\n");
    }
}
    //public void displayBoard(){


