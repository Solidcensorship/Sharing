import java.util.*;

public class Board {
    Scanner scan = new Scanner(System.in);
    Scanner scanNum = new Scanner(System.in);
    Random random = new Random();
    int numberOfPlayers;
    int total_Tiles;
    Player[] player;
    //storing habitats and animals
    ArrayList<String> name = new ArrayList<>();
    ArrayList<String> habitats = new ArrayList(15);
    ArrayList<String> animals = new ArrayList(15);
    ArrayList<String> starterHabitat = new ArrayList(15);
    LinkedHashMap<String, String> personToStartHabitat = new LinkedHashMap<>();


    public void setupBoard() {
        Collections.addAll(habitats, "forest", "wetland", "river", "mountain", "prairie", "blank");
        Collections.addAll(animals, "foxes", "elks", "salmon", "bears", "hawks");
        Collections.addAll(starterHabitat, "A", "B", "C", "D", "E");
    }

    public void setupPlayer() {
        System.out.println("enter a number of players, 4 max.");
        numberOfPlayers = scanNum.nextInt();
        total_Tiles = numberOfPlayers * 20 + 3;

        //Player creation
        player = new Player[numberOfPlayers];

        for (int i = 0; i < numberOfPlayers; i++) {
            System.out.print("Enter player " + (i + 1) + "'s name: ");
            String playerName = scan.nextLine();
            player[i] = new Player(playerName, 0);
            Collections.addAll(name, player[i].getPlayerName());
        }
    }

          public void setOrder(){
           Collections.shuffle(name);
            System.out.println("The order is as follows: " + name + "\n");

        }


        public void assignStarterTile(){
            for (int i = 0; i < numberOfPlayers; i++) {
                int randomNum = random.nextInt(starterHabitat.size());
                String person = name.get(i);
                String startHab = starterHabitat.get(randomNum);
                System.out.println(person + " starts with habitat tile " + startHab);
                personToStartHabitat.put(person, startHab);
                starterHabitat.remove(randomNum);
            }

            for (Map.Entry<String, String> entry : personToStartHabitat.entrySet()) {
                System.out.println(entry.getKey() + "'s board:" + entry.getValue());
        }


    }

    public void turn(int currentPlayerIndex) {
        Player currentPlayer = player[currentPlayerIndex];
        System.out.println("Player" + player[currentPlayerIndex].getPlayerName() + "'s Turn.\n");
        // current player to makes a move
        // update the players board

        currentPlayerIndex = (currentPlayerIndex + 1) % player.length;

    }
}

